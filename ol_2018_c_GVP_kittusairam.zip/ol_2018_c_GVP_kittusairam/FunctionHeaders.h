long long minimumPieceMoves(long long, long long,long long, long long , char );

int MaxGold(struct node* root);

char * NearestSortedNumber(char *N, int len);

int RepeatedDivision(int N);

struct loopnode * createFormation(char *str);
char * storeFormation(struct loopnode* head);

void mergerow(int *row, int len, char direction);

int lastOne(int *values, int N, int M);